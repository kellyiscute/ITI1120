import math


def deg_rad(deg):
    return math.pi/180*deg


def calc_distance(v):
    result = []
    for i in range(10, step=10):
        theta = deg_rad(i)
        result.append((2 * v ** 2 * math.cos(theta) * math.sin(theta)) / 9.8)


v = input('velocity = ')
print(calc_distance(v))
