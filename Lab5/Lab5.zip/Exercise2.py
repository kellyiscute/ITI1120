def calc_average(nums):
    sum = 0
    for i in nums:
        sum += i
    return sum / len(nums)


l = eval(input('Input a list of student\'s mark: '))
print([calc_average(l), max(l), min(l)])
