# Display integers a, a+1, a+2, ..., b
def display(a,b):
    ## complete your work here ##
    for i in range(a, b+1):
        print(i)

    
    return 
a = int(input("Please prvide a value for a: "))
b = int(input("Please prvide a value for b: "))
display(a,b)
