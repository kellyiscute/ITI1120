def bmi(p, t):
    ## complete your work here ##

    ## return something for now
    return r

def print_bmi_level(r):
    ## complete your work here ##

    return

p = float(input("Enter your weight in kilograms "))
t = float(input("Enter your height in meters "))

r = bmi(p,t)
print("Your BMI is", r)
print_bmi_level(r)
