﻿import random

def doTest(operation): 
    ## complete your work here ##


    
    # return True for now
    return True
    
responsesCorrect = 0
print("The software will process a test with 10 questions …… ")
for compteur in range (10):
    operation = random.randint(0,1)
    if doTest(operation) == True:
         responsesCorrect += 1
print(responsesCorrect, "Correct responses")         
if responsesCorrect  <= 6 :
  print("Ask some help from your instructor.")
else:
  print("Congratulations!")
