def performTest(operation): 
    ## complete your work here ##


    return correctCounts
    
print("This software tests you with 10 questions …… ");
operation = int(input("0) Addition \n1) Multiplication\nPlease make a selection (0 or 1): "))
      
correctCounts = performTest(operation)
        
if correctCounts <= 6 :
  print("Please ask your teacher for help.")
else:
  print("Congratulations!")
